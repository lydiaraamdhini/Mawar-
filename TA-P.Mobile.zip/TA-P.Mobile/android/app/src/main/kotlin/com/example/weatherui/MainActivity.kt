package com.example.weatherui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
